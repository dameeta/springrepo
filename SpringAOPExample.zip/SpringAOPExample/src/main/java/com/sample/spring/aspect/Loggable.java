package com.sample.spring.aspect;

public @interface Loggable {

}
